import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import Login from './pages/Login'
import ClienteLista from './pages/clientes/ClienteLista'
import ClienteCadastro from './pages/clientes/ClienteCadastro'
import ClienteEdicao from './pages/clientes/ClienteEdicao'

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/clientes" element={<ClienteLista />} />
        <Route path="/clientes/novo" element={<ClienteCadastro />} />
        <Route path="/clientes/:id" element={<ClienteEdicao />} />
      </Routes>
    </BrowserRouter>
  )
}