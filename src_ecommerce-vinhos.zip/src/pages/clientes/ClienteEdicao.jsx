import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { buscarClientePorId, atualizarCliente } from '../../services/clienteService'

export default function ClienteEdicao() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [form, setForm] = useState(null)
  const [erro, setErro] = useState('')

  useEffect(() => {
    const cliente = buscarClientePorId(id)
    if (cliente) setForm(cliente)
  }, [id])

  if (!form) return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '48px 32px' }}>
      <p style={{ color: 'var(--muted)' }}>Cliente não encontrado.</p>
      <button onClick={() => navigate('/clientes')}
        style={{ background: 'none', border: 'none', color: 'var(--wine)', cursor: 'pointer', marginTop: 12 }}>
        ← Voltar para listagem
      </button>
    </div>
  )

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  function handleSubmit(e) {
    e.preventDefault()
    setErro('')
    if (!form.nome || !form.email || !form.telefone) {
      setErro('Nome, e-mail e telefone são obrigatórios.')
      return
    }
    atualizarCliente(id, form)
    alert('Cliente atualizado com sucesso!')
    navigate('/clientes')
  }

  const inputStyle = {
    width: '100%', border: '1px solid var(--border)', borderRadius: 8,
    padding: '10px 14px', fontSize: 14, fontFamily: 'DM Sans, sans-serif',
    outline: 'none', boxSizing: 'border-box'
  }

  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '48px 32px' }}>
      <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 32, marginBottom: 32 }}>Editar cliente</h1>

      {erro && (
        <div style={{
          background: '#FEF2F2', border: '1px solid #FECACA',
          borderRadius: 8, padding: '12px 16px', color: '#991B1B', fontSize: 13, marginBottom: 20
        }}>
          {erro}
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>Nome completo</label>
          <input name="nome" value={form.nome} onChange={handleChange} required style={inputStyle} />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>E-mail</label>
          <input type="email" name="email" value={form.email} onChange={handleChange} required style={inputStyle} />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>CPF</label>
          <input value={form.cpf} disabled style={{ ...inputStyle, background: '#F9FAFB', color: 'var(--muted)', cursor: 'not-allowed' }} />
          <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>CPF não pode ser alterado.</p>
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>Data de nascimento</label>
          <input type="date" value={form.dataNascimento} disabled style={{ ...inputStyle, background: '#F9FAFB', color: 'var(--muted)', cursor: 'not-allowed' }} />
          <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>Data de nascimento não pode ser alterada.</p>
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>Gênero</label>
          <select name="genero" value={form.genero} onChange={handleChange} required style={inputStyle}>
            <option value="">Selecione</option>
            <option value="masculino">Masculino</option>
            <option value="feminino">Feminino</option>
            <option value="outro">Outro</option>
            <option value="prefiro_nao_informar">Prefiro não informar</option>
          </select>
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 13, color: 'var(--muted)', marginBottom: 6 }}>Telefone</label>
          <input name="telefone" value={form.telefone} onChange={handleChange} required placeholder="(11) 99999-9999" style={inputStyle} />
        </div>
        <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
          <button type="submit" style={{
            background: 'var(--wine)', color: '#fff', border: 'none',
            borderRadius: 8, padding: '11px 24px', fontSize: 14,
            cursor: 'pointer', fontFamily: 'DM Sans, sans-serif'
          }}>
            Salvar alterações
          </button>
          <button type="button" onClick={() => navigate('/clientes')} style={{
            background: 'transparent', border: '1px solid var(--border)',
            borderRadius: 8, padding: '11px 24px', fontSize: 14,
            cursor: 'pointer', color: 'var(--muted)', fontFamily: 'DM Sans, sans-serif'
          }}>
            Cancelar
          </button>
        </div>
      </form>
    </div>
  )
}