import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { cadastrarCliente } from '../../services/clienteService'

export default function ClienteCadastro() {
  const navigate = useNavigate()
  const [form, setForm] = useState({
    nome: '', email: '', cpf: '', dataNascimento: '',
    genero: '', telefone: '', senha: '', confirmarSenha: '',
  })
  const [erro, setErro] = useState('')

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  function calcularIdade(dataNascimento) {
    const hoje = new Date()
    const nascimento = new Date(dataNascimento)
    let idade = hoje.getFullYear() - nascimento.getFullYear()
    if (hoje.getMonth() < nascimento.getMonth() ||
      (hoje.getMonth() === nascimento.getMonth() && hoje.getDate() < nascimento.getDate())) {
      idade--
    }
    return idade
  }

  function handleSubmit(e) {
  e.preventDefault()
  setErro('')

  if (calcularIdade(form.dataNascimento) < 18) {
    setErro('É necessário ter 18 anos ou mais para se cadastrar. (RN0071)')
    return
  }
  if (form.senha !== form.confirmarSenha) {
    setErro('As senhas não coincidem.')
    return
  }
  const senhaForte = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/.test(form.senha)
  if (!senhaForte) {
    setErro('Senha deve ter 8+ caracteres, maiúscula, minúscula e caractere especial. (RNF0031)')
    return
  }

  cadastrarCliente(form)
  alert('Cliente cadastrado com sucesso!')
  navigate('/clientes')
}

  return (
    <div className="max-w-2xl mx-auto p-8">
      <h1 className="text-2xl font-semibold text-gray-800 mb-6">Cadastro de cliente</h1>

      {erro && (
        <div className="bg-red-100 text-red-800 border border-red-300 rounded px-4 py-3 mb-6">
          {erro}
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="block text-sm text-gray-600 mb-1">Nome completo</label>
          <input name="nome" value={form.nome} onChange={handleChange} required
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">E-mail</label>
          <input type="email" name="email" value={form.email} onChange={handleChange} required
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">CPF</label>
          <input name="cpf" value={form.cpf} onChange={handleChange} required
            placeholder="000.000.000-00"
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Data de nascimento</label>
          <input type="date" name="dataNascimento" value={form.dataNascimento} onChange={handleChange} required
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Gênero</label>
          <select name="genero" value={form.genero} onChange={handleChange} required
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm">
            <option value="">Selecione</option>
            <option value="masculino">Masculino</option>
            <option value="feminino">Feminino</option>
            <option value="outro">Outro</option>
            <option value="prefiro_nao_informar">Prefiro não informar</option>
          </select>
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Telefone</label>
          <input name="telefone" value={form.telefone} onChange={handleChange} required
            placeholder="(11) 99999-9999"
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Senha</label>
          <input type="password" name="senha" value={form.senha} onChange={handleChange} required
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Confirmar senha</label>
          <input type="password" name="confirmarSenha" value={form.confirmarSenha} onChange={handleChange} required
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm" />
        </div>
        <div className="flex gap-3 mt-2">
          <button type="submit"
            className="bg-red-800 text-white px-6 py-2 rounded hover:bg-red-900 text-sm">
            Cadastrar
          </button>
          <button type="button" onClick={() => navigate('/clientes')}
            className="border border-gray-300 text-gray-600 px-6 py-2 rounded hover:bg-gray-50 text-sm">
            Cancelar
          </button>
        </div>
      </form>

      <p className="text-xs text-gray-400 mt-8">
        Beba com moderação. Venda proibida para menores de 18 anos. (RN0082)
      </p>
    </div>
  )
}