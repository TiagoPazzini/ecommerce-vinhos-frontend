import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: '', senha: '' })
  const [erro, setErro] = useState('')

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  function handleSubmit(e) {
    e.preventDefault()
    setErro('')

    if (form.email === 'admin@vinho.com' && form.senha === 'Admin@123') {
      alert('Login realizado com sucesso!')
      navigate('/clientes')
      return
    }

    setErro('E-mail ou senha inválidos.')
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white rounded-lg border border-gray-200 p-8 w-full max-w-sm">

        <h1 className="text-2xl font-semibold text-gray-800 mb-1">Bem-vindo</h1>
        <p className="text-sm text-gray-400 mb-6">Acesse sua conta</p>

        {erro && (
          <div className="bg-red-100 text-red-800 border border-red-300 rounded px-4 py-3 mb-4 text-sm">
            {erro}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">E-mail</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              required
              placeholder="seu@email.com"
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Senha</label>
            <input
              type="password"
              name="senha"
              value={form.senha}
              onChange={handleChange}
              required
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </div>
          <button
            type="submit"
            className="bg-red-800 text-white px-6 py-2 rounded hover:bg-red-900 text-sm mt-2"
          >
            Entrar
          </button>
        </form>

        <p className="text-xs text-gray-400 mt-8 text-center">
          Beba com moderação. Venda proibida para menores de 18 anos.
        </p>
      </div>
    </div>
  )
}