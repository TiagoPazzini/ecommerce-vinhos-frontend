import { Link, useLocation } from 'react-router-dom'

export default function Navbar() {
  const location = useLocation()
  if (location.pathname === '/login') return null

  return (
    <nav style={{ background: 'var(--wine-dark)', borderBottom: '1px solid var(--wine)' }}
      className="px-8 py-0 flex items-center justify-between">

      <Link to="/" className="flex items-center gap-3 py-4 no-underline">
        <div style={{
          width: 32, height: 32, borderRadius: '50%',
          background: 'var(--gold)', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 16
        }}>🍷</div>
        <span style={{
          fontFamily: 'Playfair Display, serif',
          color: 'var(--cream)', fontSize: 20, fontWeight: 600, letterSpacing: '0.02em'
        }}>
          Vinho & Co.
        </span>
      </Link>

      <div className="flex items-center gap-1">
        {[
          { to: '/clientes', label: 'Clientes' },
        ].map(({ to, label }) => {
          const active = location.pathname.startsWith(to)
          return (
            <Link key={to} to={to} style={{
              color: active ? 'var(--gold)' : 'rgba(248,244,239,0.6)',
              borderBottom: active ? '2px solid var(--gold)' : '2px solid transparent',
              padding: '20px 16px', fontSize: 14, fontWeight: 500,
              textDecoration: 'none', transition: 'all 0.2s'
            }}>
              {label}
            </Link>
          )
        })}

        <Link to="/login" style={{
          marginLeft: 16, padding: '8px 20px',
          border: '1px solid var(--gold)', borderRadius: 6,
          color: 'var(--gold)', fontSize: 13, fontWeight: 500,
          textDecoration: 'none', transition: 'all 0.2s'
        }}
          onMouseOver={e => { e.target.style.background = 'var(--gold)'; e.target.style.color = 'var(--wine-dark)' }}
          onMouseOut={e => { e.target.style.background = 'transparent'; e.target.style.color = 'var(--gold)' }}>
          Sair
        </Link>
      </div>
    </nav>
  )
}